package exam.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import exam.model.examModel;
import exam.model.questionModel;
import exam.model.registrationmodel;

public class mainExamDAO {
	 private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	     
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/examdb","root","");  
	    
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	 
	  public static ArrayList<questionModel> getQuestionForStud(String sub_name, int clss_no)
	  {
		  ArrayList <questionModel> quelist=new ArrayList<questionModel>();
		  questionModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select q_id, clss_no, que, op1, op2, op3, op4, ans, sub_name from question where sub_name=? and clss_no=? "); 
	      stmt.setString(1, sub_name);
	      stmt.setInt(2, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			  temp=new questionModel(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));	
			  quelist.add(temp); 		  
			  }  
		     closeConnection();	 
		     return quelist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  public static ArrayList<examModel> getExamDetail(int clss_no)
	  {
		  ArrayList <examModel> quelist=new ArrayList<examModel>();
		  examModel temp;
		
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select sub_name, clss_no from exam where clss_no=? "); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			  temp=new examModel(rs.getString(1),rs.getInt(2));	
			  quelist.add(temp); 		  
			  }  
		     closeConnection();	 
		     return quelist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static int getQuestionCount(int clss_no, String sub_name)
	  {
		  int n=0;
		
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select count(*) from question where clss_no=? and sub_name=? "); 
	      stmt.setInt(1, clss_no);
	      stmt.setString(2, sub_name);
		  ResultSet rs=stmt.executeQuery();
		  while(rs.next())
			  {  		   
			 n=rs.getInt(1);		  
			  }  
		     closeConnection();	 
		     return n;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return 0; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return 0; }  	  
	  }
}
