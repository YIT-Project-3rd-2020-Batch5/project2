package exam.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.loginDAO;

@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		String uname=request.getParameter("email");
		String pass=request.getParameter("pass");
		HttpSession session1=request.getSession();
		HttpSession session3=request.getSession();
		session1.removeAttribute("email_id");
		session1.removeAttribute("pass");
		if(session1.getAttribute("email_id")==null)
		  session1.setAttribute("email_id",uname);
		if(session1.getAttribute("pass")==null)
			  session1.setAttribute("pass",pass);
		if(uname!=null && pass!=null)
		{
			if(loginDAO.login(uname,pass)==true)
				
			{
				rd=request.getRequestDispatcher("indexController");
				rd.forward(request, response);
	}else
	{
		request.setAttribute("errormsg", "Please enter the credentials");
		
		rd=request.getRequestDispatcher("login.jsp");
		rd.forward(request, response);
	}
		}
		
			else if(uname==null)
		{
			request.setAttribute("errormsg", "Please enter the correct credentials");
			rd=request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}
		else if(pass==null)
		{
			request.setAttribute("errormsg", "Please enter the password");
			rd=request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
