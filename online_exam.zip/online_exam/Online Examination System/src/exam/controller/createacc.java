package exam.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import exam.DAO.registerDAO;
import exam.model.registrationmodel;


@WebServlet("/createacc")
public class createacc extends HttpServlet {
	private static final long serialVersionUID = 1L;
   int n=1;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		String utype="user";		
		String email_id=request.getParameter("email");
		String name=request.getParameter("uname");
		
		String password=request.getParameter("pass");
		String pass1=request.getParameter("pass1");
		String mobile_no=request.getParameter("mobno");
		int class_no=Integer.parseInt(request.getParameter("classno"));
		String security_qn=request.getParameter("secque");
		String security_ans=request.getParameter("secans");
		int school_reg_no=Integer.parseInt(request.getParameter("rollno"));
		String gender=request.getParameter("gender");
		
		if (password.equals(pass1))
		{
			registrationmodel r1=new registrationmodel(name, gender, email_id, password, mobile_no, class_no, security_qn, security_ans, school_reg_no, utype);
			
			if(registerDAO.createacc(r1)==true)
			{
			rd=request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
			}
		}else
			{
				request.setAttribute("errormsg", "Password mismatch, Please enter the correct password");
				rd=request.getRequestDispatcher("createacc.jsp");
				rd.forward(request, response);
			}
		
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
